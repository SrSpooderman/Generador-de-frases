V1
Crea un diccionario donde se almacenan todas las palabras con la siguiente a ella.
Crea un array donde se almacenan las palabras iniciales
La frase se crea en un string
Las frases terminan cuando sale una palabra sin valores
V2
Los procesos del programa estan hechos mediante funciones
Las palabras finales de cada frase tienen un valor FiNaL para remarcar el final de la frase
V3
Las key del diccionario son de n cantidad de palabras
El array de palabras iniciales esta implementado en el diccionario
Las key de diccionario tienen un formato
Se crea un documento de texto limpio sin '.:/\(),;', con el cual trabajaremos para no modificar el archivo original
Un diccionario para que no repitan las frases
V4
Arreglado un error en el formato para que no se repitan las frases.